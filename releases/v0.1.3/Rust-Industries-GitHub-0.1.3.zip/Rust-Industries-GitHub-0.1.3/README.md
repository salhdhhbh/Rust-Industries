# Rust Industries — 0.1.3

A Horizon Android mod package.

## Version 0.1.3 fixes
- Removed the unsupported `random_ticks` property from the four crop block definitions (`copper_crop`, `diamond_crop`, `gold_crop`, and `iron_crop`).
- Kept the remaining mod assets, data, and `horizon-mod.toml` from the supplied 0.1.3 package.

## Files
- `assets/` — block states, models, textures, and language resources.
- `data/` — recipes, loot tables, and other game data.
- `horizon-mod.toml` — Horizon mod metadata.
- `RustIndustries-0.1.3.hmod` — packaged mod for installation.

## Install
Remove older Rust Industries copies from the game's Mods folder, then install `RustIndustries-0.1.3.hmod`.

## Validation note
The archive structure and JSON syntax were checked. A live in-game launch test has not been performed, so runtime compatibility is not guaranteed.
